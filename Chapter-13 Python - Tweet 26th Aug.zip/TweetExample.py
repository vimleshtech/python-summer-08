import tweepy
from tweepy import OAuthHandler #authenication

API_key='TL7RyLnfilYH6xaoAlS0XFDCg'
API_secret_key='u5uBn4P62PMIxT4uwUVTl1Ycx4rsfByFs6jl2e4SQ9zDjPIzCO'
Access_token='919434545924935681-2woCDEXuXQdhJewDaCRBqHBYmi5SFDN'
Access_token_secret='T29jqUm6rZqsRYO7AGc47GlgYTaAaN5OtJD0DATo1uBjh'


a=OAuthHandler(API_key, API_secret_key)
a.set_access_token(Access_token, Access_token_secret)

api = tweepy.API(a)
print('Login success')

res = api.search(q='Narendra Modi',count=15)

for r in res:
    print(r.text)


    










            


