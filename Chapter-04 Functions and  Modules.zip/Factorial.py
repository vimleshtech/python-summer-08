#recussive function
def rec(x):
     if x==1:
          return x
     else:
          return x*rec(x-1) #6*5*4*3*2*1



#function with default value
def add(a,b=0,c=0,d=0): #a is madatory argument, and b,c,d are optional
     x = a+b+c+d
     print(x)
     

#function with dynamic arguments
def mul(*x): #* : receive all data or values
     print(x)
     o =1
     for m in x:
          o*=m

     print(o)
     

#lambda function 
y = lambda x: x*.10
'''
def y(x):
     x = x*.10
     return x
'''
o = rec(6)
print(o)

add(4)
add(4,444)
add(4,55,33)
add(4,4444,333)
add(4,4444,555,333)

mul(111,2233,44)
mul(111,2233,44,44,22,33,4,2,3,4,3,4,4)


print(y(140))




