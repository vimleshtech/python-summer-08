import os

import shutil
f = os.listdir(r'C:\Users\vkumar15\Documents')  #r : skip the unicode

print(type(f)) #list
#get .txt file count
c =0

for r in f:
     if r.endswith('.txt'):
          c =c+1

print('text file count :',c)


     
shutil.copy(r'C:\Users\vkumar15\Desktop\Questions.doc',r'C:\Users\vkumar15\Desktop\Tax')
print('file is copied')
