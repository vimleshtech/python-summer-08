#no argument no return 
def info():
     print('Sal Calculations: - hra is 40% of baisc, da is 20% of basic, msal is bsal + hra+da')
     print('no tax < 300000, 5% till 500000, 20% till 1000000 , 30% over 1000000')
     
     
def msal(bsal):
     hra = bsal*.40
     da = bsal*.20
     msal = bsal+hra+da
     return msal 

def ysal(sal):
     ysal = sal*12
     pf = sal*.12
     nsal = ysal -pf
     return ysal
     
def tax(ysal):
     
     if ysal<=300000:
          t= 0
     elif ysal<=500000:
          t = (ysal-300000)*.05
     elif ysal<=1000000:
          t = 10000+(ysal-500000)*.20
     else:
          t = 110000+(ysal-1000000)*.30

     return t


info()
sal = msal(45000)
ys = ysal(sal)
t = tax(ys)
print('monthly sal is :',sal)
print('monthly ysal is :',ys)
print('monthly tax is :',t)



     
          
     
