#import file / load module
import mylib #here mylib is name of module

mylib.info()
o = mylib.msal(4444)
print(o)


#or
import mylib as m #here m is alias of mylib
m.info()

#or
from mylib import *  #*: import all functions
info()
x = msal(3334)
print(x)


#or
from mylib import info,tax #import selected functions
info()
a = tax(444555)
print(a)








