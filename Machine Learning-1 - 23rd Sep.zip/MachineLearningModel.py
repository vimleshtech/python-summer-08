import pandas
import matplotlib.pyplot as plt
from sklearn import model_selection

url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
cols = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']
dataset = pandas.read_csv(url, names=cols)

print(dataset)

##
print(dataset.columns)
print(dataset.head())
print(dataset.tail())

##
print(dataset.info())

##stats
print(dataset.describe())

##corr
print(dataset.corr())
'''
-1 : negative correlation
0  : no-correlation
+1 : positive-corelation 

'''

##visualize the data
#dataset.plot()
#dataset.plot(kind='box')
#dataset.plot(kind='line',subplots=True)
dataset.plot(kind='line',subplots=True,layout=(2,2))

plt.show()


#data extraction : split data in train and test
#80% data train , and 20% test

array = dataset.values #convert dataframe to array
X = array[:,0:4] #extract all rows and first 4 columns on X variable
Y = array[:,4]  #extract all rows and 5 column on Y variable 

validation_size = 0.20 #set % test data  20%
seed = 7  #random value, every 8 rows

X_train, X_validation, Y_train, Y_validation =model_selection.train_test_split(X, Y, test_size=validation_size, random_state=seed)

print(len(X_train))
print(len(X_validation))
print(len(Y_train))
print(len(Y_validation))

















