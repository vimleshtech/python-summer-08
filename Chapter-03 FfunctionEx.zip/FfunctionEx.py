#no argument no return 
def test(): #here def keyword and test is name of function
     a =  11
     b = 333
     print('welcome to function world ')
     print(a+b)

#no argument with return 
def getNum():
     a = int(input('enter num :'))
     b = int(input('enter num :'))
     return a,b 

#argument with no return
def add(a,b):
     print(a+b)

#argument with return
def sub(a,b):
     c =a-b
     return c

#call to function
test()
test()
test()
x,y = getNum()
print(x*y)


add(11,3)
o = sub(11,33)
print(o)





