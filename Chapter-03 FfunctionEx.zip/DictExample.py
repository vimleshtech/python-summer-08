a ={'a':'alpha','b':'beta',1:100,10:[1,'raman','male']}

print(a)
print(a.values())
print(a.keys())

print(a['b'])

#add new key
a['t']='tata'
print(a)



