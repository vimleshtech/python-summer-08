s = input('enter string :')

print(s.upper())
print(s.lower())
print(s.title())
print(s.strip())  #is just like trim()
print(len(s))
print(s.count('is'))

o = list(s)
print(o)
 
print(s.replace('a','xy')) #a is old char and xy is new

o = s.split(' ')
print(o)

if s.isdigit():
     print('numebr')
else:
     print('alpha numeric')



if s.islower():
     print('lower case')
else:
     print('other case')


if s.isupper():
     print('upper case')
else:
     print('other case')


if s.endswith('de'):
     print('ending with de')
else:
     print('not ending with de')
     








     

     







     





           

