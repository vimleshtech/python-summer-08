import requests
from bs4 import BeautifulSoup

url ='https://www.imdb.com/list/ls055386972/'

res = requests.get(url)
data = res.content
r = BeautifulSoup(data,'html.parser')


items = r.findAll("div", {"class": "lister-item-content"} )

m_title = []
m_rating = []
m_meta = []

for i in items:
    #print(i.text)
    h3 = i.findAll("h3", {"class":"lister-item-header"})
    title = h3[0].findAll('a')
    print(title[0].text,end=' ')
    m_title.append(title[0].text)
    
    div = i.findAll("div", {"class":"ipl-rating-widget"})
    ratings = div[0].findAll("div", {"class":"ipl-rating-star small"})
    rate = ratings[0].findAll("span", {"class":"ipl-rating-star__rating"})
    print(rate[0].text,end=' ')
    m_rating.append(rate[0].text)


    m = 0
    try:
        div = i.findAll("div", {"class":"inline-block ratings-metascore"})
        meta = div[0].findAll("span")
        if len(meta)>0:
            print(meta[0].text)
            m = meta[0].text
        
    except:
        pass
    

    m_meta.append(m)

    
#create dataframe
import pandas as pd
mov = pd.DataFrame(data={'Title':m_title,'Rating':m_rating,'Meta_Score':m_meta})
print(mov)

mov.to_csv('movie_rating.csv',index=False)
print('data is saved')







