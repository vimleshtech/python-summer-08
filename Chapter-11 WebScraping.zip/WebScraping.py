#web scraping
#pip instsll requests
#pip install bs4

import requests
from bs4 import BeautifulSoup


#send request to yahoo page
res = requests.get('http://www.yahoo.com/')
print(res) #200 response code for ok(website is responding)

#print
#print(res.content)

data = res.content
#convert the content to html parser
items = BeautifulSoup(data,'html.parser')

out = items.findAll('a') #anchor tag or hyperlink
print(len(out))

#read content from a tag
for d in out:
    print(d.text)
    






