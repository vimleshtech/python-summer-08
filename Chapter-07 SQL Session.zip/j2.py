class emp:

     def newemp(s):
          s.eid = int(input('ener eid :'))
          s.name = input('enter name :')
          s.bsal = int(input('enter sal :'))
          

     def cal(s):
          s.hra = s.bsal*.40
          s.da = s.bsal*.20
          s.msal = s.hra+s.da
          s.ysal = s.msal *12


     def show(s):
          print(s.eid,' ',s.name,' ')
          print(s.hra)
          print(s.da)
          print(s.msal)
          print(s.ysal)
     def geteid(s):
          return s.eid
     

l = []
for x in range(5):
     e = emp()
     e.newemp()
     e.cal()

     l.append(e)

#sorting
for i in range(0,len(l)):
     for j in range(i+1,len(l)):
          if l[i].geteid() > l[j].geteid():
               temp = l[i]
               l[i] = l[j]
               l[j] = temp 
                      
     


#for o in l:
#     o.show()

for i in range(0,len(l)):
     l[i].show()
     


