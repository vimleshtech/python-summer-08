import mysql.connector as con

#establish the connection from pyton to database server
c = con.connect(host='localhost',user='root',password='root',database='student')

#create object of cursor to execute sql command
cur = c.cursor()

cur.execute('select * from employee')

#get data , command output
o = cur.fetchall()
#print(o)
for r in o:
     print(r[0],r[1])
     


