#Machine Learning
#Load Data Distribuation and Variance Analysis
'''
There are following steps:
i. Upload data
ii. crean data or convert data in required format
iii. Explore the data
iv. Show Distribuation
v. Show Variance by thier different factor
'''

import os
import pandas as pd
import matplotlib.pyplot as plt

#change or set working directory
os.chdir(r'C:\Users\NITS\Desktop\Desktop - Raman')

data = pd.read_csv('Loan_data.csv')
print(data.head())
print(data.shape)
print(data.columns)
print(data.info())


print(data.describe())


'''
Loan_ID              614 non-null object
Gender               601 non-null object
Married              611 non-null object
Dependents           599 non-null object
Education            614 non-null object
Self_Employed        582 non-null object
ApplicantIncome      614 non-null int64
CoapplicantIncome    614 non-null float64
LoanAmount           592 non-null float64
Loan_Amount_Term     600 non-null float64
Credit_History       564 non-null float64
Property_Area        613 non-null object
Loan_Status          613 non-null object
'''

#Data Distribuation
print('By Gender :',data.groupby('Gender').size())
print('By M.Status :',data.groupby('Married').size())
print('By E.Status :',data.groupby('Self_Employed').size())
print('By T.Loan :',data.groupby('Loan_Amount_Term').size())
print('By L.Status :',data.groupby('Loan_Status').size())
'''
By L.Status : Loan_Status
N    191
Y    422   loan applications are approved

'''


'''
By E.Status : Self_Employed
No     500  more applicant are working employee
Yes     82  less applicant are self employee
'''

#Show Variance
#show approved and not approved application status


#data['ApplicantIncome'].plot(kind='box')

data['Loan_Amount_Term'].plot(kind='box')

plt.show()





