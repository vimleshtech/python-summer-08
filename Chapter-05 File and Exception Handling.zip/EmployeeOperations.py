f = open(r'C:\Users\vkumar15\Desktop\data\emp.txt')

d = f.readlines()

mc =0
ms = 0
fc =0
fs = 0

for r in d:
     c =r.split(',')
     if c[2] =='male':
          mc +=1
          ms += int(c[3]) #type case/convert string to int to get total sal
     elif c[2] =='female':
          fc +=1
          fs += int(c[3]) #type case/convert string to int to get total sal

print('male count ',mc,' total sal ',ms)
print('female  count',fc,' total sal ',fs)





          
     
