#read csv
import pandas 
df = pandas.read_csv(r'C:\Users\vkumar15\Desktop\data\employee.csv')

print(df) #show all data

#show particular column
print(df['name'])
print(df[['name','salary']])



##read excel file
data = pandas.read_excel(r'C:\Users\vkumar15\Desktop\data\data.xlsx',sheet_name='Sales')
print(data)


d = pandas.read_excel(r'C:\Users\vkumar15\Desktop\data\data.xlsx',sheet_name='Sheet2')
print(d)
