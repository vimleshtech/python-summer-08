#r - read mode
#f = open(r'C:\Users\vkumar15\Desktop\data\test1.txt')

#default mode is read 
f = open(r'C:\Users\vkumar15\Desktop\data\test1.txt')

#print(f.read()) #read all data / content

#print(f.readline()) #read one line from file , 1st line
#print(f.readline()) #2nd line
#print(f.readline()) #3rd line

#read all data from from file and convert to list
data = f.readlines() #type of data is list now
#print(data)

print(data[1]) #2nd line

#show no from rows in file
print('Row count :',len(data))

#get word count
wc =0
for r in data: #print line by line 
     #print(r)
     c = r.split(',')
     wc = wc+len(c)


print('word count :',wc)


     
     


     
      



f.close()


