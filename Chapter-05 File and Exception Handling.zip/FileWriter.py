
#create a file in write mode
f = open(r'C:\Users\vkumar15\Desktop\data\test1.txt','w')

f.write('Hi Raman \n') #\n : new line
f.write('end of line\n')

f.close()
print('file is saved')


##open the file in append mode , data will not be overwritten
f = open(r'C:\Users\vkumar15\Desktop\data\test1.txt','a')
for x in range(1,5):
     s = input('enter data :')
     f.write(s+'\n') #\n for line line

f.close()





     

