#WAP to keep asking the inputs until result will not come

while True: #infinite

     try:
          
          a = int(input('enter data'))
          b = int(input('enter data'))
          c =a+ b
          print(c)
          
          break
     except:
          print('given input is correct, plz enter data again !!')
     
     
     
