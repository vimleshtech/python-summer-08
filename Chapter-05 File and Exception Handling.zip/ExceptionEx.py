#division and addition example

n = int(input('enter num :'))
d = int(input('enter num :'))

'''
error type:
ZeroDivisionError
NameError
IndexError
'''
#div
try:
     if d<0:
          msg = NameError('Divisor cannot be less than 0')
          raise msg
     
     o =n/d
     print(o)
except ZeroDivisionError as er: #here er is variable which will recive msg
     print(er)
except NameError as er:
     print(er)
except:
     print('there is logical error, plz contact dev team')
     #pass
finally:  #this block will execute always either error will occur or not 
     print('end of the code ')
     
#addition 
o =n+d
print(o)







