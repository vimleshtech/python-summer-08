f = open('employee.txt') #default mode is r (read)

#id,name,gender,country,salary
data = f.readlines()

india = open('india.txt','w')
us = open('us.txt','w')
aus = open('aus.txt','w')

for r in data:
     word = r.split(',')
     if word[3] =='india':
          india.write(r)
     elif word[3] =='us':
          us.write(r)

     elif word[3]=='aus':
          aus.write(r)

india.close()
us.close()
aus.close()


          

