class Users: #user is inbuilt class

     def newUser(user):  #newUser() is function  , user is variable which takes reference of object

          user.uid = input('enter uid :')
          user.uname = input('enter name :')
          user.email = input('enter email :')

     def showUser(user):   #showUser() is function        
          print('id is :',user.uid)
          print('name is :',user.uname)
          print('email is :',user.email)

          
#create an object of class
u = Users() #u is object and Users is class
#print(u) #<__main__.Users object at 0x000001EABEE252B0> , object address

u.newUser()
u.showUser()



     
