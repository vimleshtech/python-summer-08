class A:

     def add(add,a,b):
          print(a+b)
          
class B(A) : #here B is child class and A is parent class 
     def mul(add,x,y):
          print(x*y)
          

class C (B):
     def tax(add,amt):
          if amt>100000:
               print('taxable income')
          else:
               print('nontaxable income')

#create object of child class
o = C()
o.add(113,3)
o.mul(214,4)
o.tax(545333)












               
     
