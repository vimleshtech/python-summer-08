class Users: #user is inbuilt class

     def newUser(user):  #newUser() is function  , user is variable which takes reference of object

          user.uid = input('enter uid :')
          user.uname = input('enter name :')
          user.email = input('enter email :')

     def __init__(u): #this invoke/call automatically when object will create
          print('object is created at ',u)
          

     def __del__(u):
          print('object is removed , so you cannot use object further')
          
     def showUser(user):   #showUser() is function        
          print('id is :',user.uid)
          print('name is :',user.uname)
          print('email is :',user.email)

          
#create an object of class
u = Users() #constructor (__init__()) will be called automatically

u.newUser()
u.showUser()

del u #delete object (deallocate the memory), (__del__()) will be called automatically 

#u.showUser() #now we cannot use u







     
