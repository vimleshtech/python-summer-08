
fname = input('enter fname :')
lname = input('enter lname :')

name = fname+lname
print('name is ',name)

#wap to get sum two inputs
n1 = int(input('enter number :')) #default input type is str  , so need to convert
n2 = int(input('enter number :'))

n = n1+n2  #concat 
print('sum of two numbers :',n)


##if condition
amt = int(input('enter sales amt :'))
tax = 0
if amt >1000:
     tax = amt*.18
     print('tax is calculated')
     

total = amt+tax
print('total amt is ',total)

#if else
tax = 0
if amt >1000:
     tax = amt*.18
     print('tax is calculated')
else:
     tax = amt*.12

total = amt+tax
print('total amt is ',total)


#if elif elif ...else 
tax = 0
if amt >1000:
     tax = amt*.18
     print('tax is calculated')
elif amt >500:
     tax = amt*.12
elif amt>100:
     tax = amt*.10
else:
     tax = amt*.05

total = amt+tax
print('total amt is ',total)


#and operator
a = int(input('enter num :'))
b = int(input('enter num :'))
c = int(input('enter num :'))

if a>b and a>c:
     print('a is greater')
elif b>a and b>c:
     print('b is greater')
else:
     print('c is greater')


     
















     



