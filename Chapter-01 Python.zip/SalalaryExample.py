bsal  = 54000 #input 


#expression 
hra = bsal*.40
da  = bsal*.20
msal = bsal+hra+da
ysal = msal *12

#output 
print(msal)
print(ysal)

