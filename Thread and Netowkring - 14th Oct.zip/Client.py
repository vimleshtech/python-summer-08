
import socket


s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name
port = 1244                # Reserve a port for your service.

s.connect((host, port))

print (s.recv(1024)) #rceive the data from server, 1024 byte size 
s.close()
