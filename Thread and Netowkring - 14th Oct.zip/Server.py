import socket #is module or package 

s = socket.socket()  #and socket() is class

host = socket.gethostname() # Get local machine name
print(host)
port = 1244 #any 2 to 6 digit unique number

s.bind((host, port))        # Bind to the port, start server

print('please wait while connecting')

s.listen(10) #10 client call call to server

while True:
    c,addr = s.accept() #conten and addr of client
    print('Got connection request from ',addr)
    c.send('test data'.encode()) #return test message to server
    c.close()

    
    


