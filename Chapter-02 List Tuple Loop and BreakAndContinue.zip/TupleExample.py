tax = (5,10,12,18,27)
print(tax) #print all data

print(tax[0]) #print first element
print(tax[1]) #print 2nd

print(type(tax)) #print data type
print(len(tax)) #print count of element

print(max(tax))  #print highest value
print(min(tax))   #print lowest value
print(sum(tax))   #print total

#find given data/value in tuple
v = int(input('enter data to search :'))

if v in tax:
     print('v is match in tax tuple')
else:
     print('v is not match')

#
wd = ('mon','tue','wed','thu','fri')

#wd[0] ='sat' #error

day = input('enter day name :')
if day in wd:
     print('working day, you can come in office')
else:
     print('weekend or other day , office is not open today. Plz visit from mon - fri')


     






     

