sales = [1233,4444,2222,3444,222,1,222,333,455]

print(sales)
print(max(sales))
print(min(sales))
print(sum(sales))
print(len(sales))

sales.append(100) #add new value 
sales.append(10)
print(sales)

sales.pop() #remove from last
sales.pop() #remove from last
sales.pop() #remove from last
print(sales)

sales.insert(2,230) #add new value at given position 
print(sales)

sales.remove(4444)
print(sales)

#replace or modify data
sales[2] =3400
print(sales)

##
sales.sort()
print(sales)


#slicer
print(sales[0:3]) #0,1,2
#or
print(sales[:3]) #0,1,2
print(sales[3:6]) #3,4,5

#print frrom right
print(sales[-1])
print(sales[-2])

print(sales[:-2]) #from 0 to 3rd last

#print in reverse
print(sales[::-1])


















