#for
#range(10) : 0 to 0
#range(0,10) : 0 to 9
#range(0,10,1) : 0 to 9
#range(0,10,2) : 0 2 4 ... 8 , here 2 is incrementer
#range(start from , < limit, increment/decrement)

for x in range(10):
     print(x)

#print table 2
for i in range(2,21,2):
     print(i)
     

#print number in reverse order
for i in range(10,-1,-1):  #from 10 to >-1  , and decrement by -1
     
     print(i)




     
