hs = int(input('enter mark :'))
es = int(input('enter mark :'))
ms = int(input('enter mark :'))
cs = int(input('enter mark :'))
sss = int(input('enter mark :'))

total = hs+es+ms+cs+sss
avg = total/5
if avg>=60:
     print('Grade A')
elif avg>=50:
     print('Grade B')
elif avg>40:
     print('Grade C')
else:
     print('Fail')
     
