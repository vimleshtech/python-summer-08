sales = [] #empty list

for i in range(1,10):
     x = int(input('enter data :'))
     sales.append(x)



print('Highest sales amt : ',max(sales))
print('Lowest sales amt :', min(sales))
print('Sum of all sales :',sum(sales))
print('Avg sales amt :',sum(sales)/len(sales))
