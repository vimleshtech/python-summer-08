#nested loop
for i in range(1,5):
     for x in range(1,4):
          print(x,end='\t')
     print() #new line 


#
'''
1
12
123
1234
'''
for i in range(1,5):
     for x in range(1,i+1): #inner loop condition is depends on parent loop 
          print('x',end='')
     print() #new line 
